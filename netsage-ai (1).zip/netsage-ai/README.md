# NetSage AI

**AI-assisted Cisco network troubleshooting platform for Packet Tracer / Cisco IOS lab environments — with mandatory human review on every recommendation.**

> AI proposes → Rule Checker validates → Human reviews → Human approves/edits/rejects → Action is logged.

NetSage AI never executes a Cisco command automatically. Every AI-generated diagnosis and fix must be explicitly Approved, Edited, or Rejected by a human before it's considered actionable, and every step is recorded in an audit log.

---

## Features

- **30-case realistic Cisco dataset** covering VLAN, Gateway, DHCP, DNS, Routing, ACL, NAT, and Wireless issues
- **Deterministic rule checker** — regex-based, zero LLM dependency, always reproducible
- **AI diagnosis engine** — provider-independent (`AIProvider` abstraction), returns strict structured JSON, grounded only in provided evidence
- **Mandatory human review** — Approve / Edit / Reject workflow; nothing is ever auto-executed
- **Full audit logging** — every rule check, AI diagnosis, and review decision is recorded
- **Simulated post-fix verification** — safe, illustrative before/after check
- **Live analytics** — AI Agreement Rate, issue/severity distributions, all computed from the database
- **Demo mode** — one click walks through the entire pipeline end to end
- **Responsible AI log** — 5 documented cases where a human reviewer corrected the AI's initial framing

---

## Architecture

```
Streamlit Frontend  ──HTTP──▶  Backend (FastAPI)
                                        │
                        ┌───────────────┼────────────────┐
                        ▼               ▼                ▼
                 Rule Checker    AI Diagnosis Engine   SQLite DB
                 (deterministic)  (OpenAI, via          (cases,
                                   AIProvider            diagnoses,
                                   abstraction)           reviews,
                                                           audit_logs)
```

The design principle — **AI proposes → Rule Checker validates → Human reviews → Human approves/rejects → Action is logged** — is enforced at the code level:
- `AIDiagnosisPayload.requires_human_review` is force-validated to `true` by a Pydantic validator; no LLM output can waive review.
- `Diagnosis.requires_human_review` is independently hardcoded at the database layer.
- A diagnosis can only be reviewed once (`review_service.py` raises on a second review attempt).
- Approval **never** executes anything — it's explicitly logged as simulated only.

See [`docs/architecture.md`](docs/architecture.md) for more detail, [`docs/model_audit_log.md`](docs/model_audit_log.md) for the audit design, [`docs/responsible_ai_log.md`](docs/responsible_ai_log.md) for documented AI corrections, and [`docs/requirements_traceability.md`](docs/requirements_traceability.md) for a full mapping of every spec requirement to its implementation.

---

## Technology Stack

**Backend:** Python 3.10+, FastAPI, SQLAlchemy, Pydantic, Pandas, SQLite (Postgres-ready), OpenAI SDK
**Frontend:** Streamlit (Python-only, no Node/npm required), `requests` for API calls, custom CSS injection for the NOC/terminal design system
**AI:** Provider-independent (`AIProvider` abstraction), OpenAI implementation included by default

---

## Folder Structure

```
netsage-ai/
├── backend/
│   ├── app/
│   │   ├── main.py              # FastAPI entrypoint, CORS, error handlers, DB init
│   │   ├── config.py             # env-driven settings (no hardcoded secrets)
│   │   ├── api/                  # cases, rules, diagnose, reviews, audit, analytics
│   │   ├── models/                # SQLAlchemy ORM models
│   │   ├── schemas/                # Pydantic request/response schemas
│   │   ├── services/                # business logic (case, diagnosis, review, audit, analytics)
│   │   ├── rules/                    # checker.py — deterministic rule engine
│   │   ├── ai/                        # provider.py (AIProvider abstraction), engine.py
│   │   └── database/                   # SQLAlchemy engine/session
│   ├── data/
│   │   ├── cases.csv              # the 30-case dataset
│   │   └── generate_cases.py       # dataset generator (provenance/reference)
│   ├── prompts/
│   │   └── diagnose_prompt.md      # AI system prompt + few-shot examples
│   ├── tests/                       # pytest suite
│   ├── requirements.txt
│   └── .env.example
├── streamlit_app/
│   ├── Dashboard.py               # main entrypoint (streamlit run Dashboard.py)
│   ├── pages/                      # 1_Troubleshoot_Case, 2_Case_Library, 3_Rule_Checker,
│   │                                # 4_AI_Diagnoses, 5_Review_Queue, 6_Audit_Log,
│   │                                # 7_Analytics, 8_Settings — Streamlit auto-builds
│   │                                # the sidebar nav from this folder
│   ├── lib/
│   │   ├── api_client.py            # central API client (requests-based)
│   │   ├── styling.py                 # CSS injection — NOC/terminal design tokens
│   │   └── components.py               # terminal output, badges, bar charts, banners
│   ├── requirements.txt
│   └── .env.example
├── docs/
│   ├── model_audit_log.md
│   ├── responsible_ai_log.md
│   ├── architecture.md
│   └── requirements_traceability.md
└── README.md
```

---

## Installation

### Prerequisites
- Python 3.10+ (used for both the backend and the Streamlit frontend — no Node/npm needed)

### Backend

```bash
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
# Edit .env and add your OPENAI_API_KEY if you want AI diagnosis enabled.
# Leaving it blank runs the app in rules-only mode — nothing breaks.
```

### Frontend (Streamlit)

```bash
cd streamlit_app
python -m venv venv             # a separate venv from the backend is recommended
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

No `.env` file is required for the default setup — the app talks to `http://localhost:8000` out of the box. Only set `NETSAGE_API_BASE_URL` (see `.env.example`) if your backend runs somewhere else; Streamlit doesn't read `.env` files automatically, so export it as a real shell environment variable if you need it.

---

## Environment Variables

**`backend/.env`**

| Variable | Purpose | Required? |
|---|---|---|
| `OPENAI_API_KEY` | LLM provider key for AI diagnosis | No — app runs in rules-only mode if blank |
| `AI_MODEL` | Model name (default `gpt-4o-mini`) | No |
| `DATABASE_URL` | SQLite by default; swappable for PostgreSQL | No |
| `CORS_ORIGINS` | Comma-separated allowed frontend origins | No |
| `APP_ENV` | `development` \| `production` | No |

**Streamlit frontend (shell environment, optional)**

| Variable | Purpose |
|---|---|
| `NETSAGE_API_BASE_URL` | Backend URL (default `http://localhost:8000`) |

Never commit a real `.env` file — only `.env.example` is checked in.

---

## Running the Application

**Backend** (from `backend/`):
```bash
uvicorn app.main:app --reload
```
Runs on `http://localhost:8000`. On first boot it auto-creates all tables and seeds the 30-case dataset from `data/cases.csv`. Interactive API docs: `http://localhost:8000/docs`.

**Frontend** (from `streamlit_app/`, in a second terminal, backend already running):
```bash
streamlit run Dashboard.py
```
Runs on `http://localhost:8501` and opens automatically in your browser. The sidebar navigation (Dashboard, Troubleshoot Case, Case Library, Rule Checker, AI Diagnoses, Review Queue, Audit Log, Analytics, Settings) is generated automatically by Streamlit from the `pages/` folder.

---

## Dataset

`backend/data/cases.csv` contains 30 realistic Cisco Packet Tracer troubleshooting cases spanning all 8 required issue types (VLAN, Gateway, DHCP, DNS, Routing, ACL, NAT, Wireless) and all 4 severities. Each case includes a symptom, topology note, raw `show`-command output, expected fault (ground truth), OSI layer, concept tag, and severity. `generate_cases.py` is the generator script kept for provenance — the app reads directly from the CSV at startup.

## Rule Checker

`backend/app/rules/checker.py` runs entirely deterministic regex-based checks against the evidence — interface status, VLAN/trunk mismatches, IP/gateway issues, routing, DHCP, ACL, NAT, and wireless problems. It has **zero dependency on the AI/LLM** and returns the same result every time for the same input (verified in `tests/test_rules.py`).

## AI Diagnosis

`backend/app/ai/engine.py` combines the case evidence, rule-checker output, and the system prompt (`prompts/diagnose_prompt.md`, which includes 3 few-shot examples) into a request to the configured `AIProvider`. The response is strictly parsed and validated against a Pydantic schema — any malformed or invalid response falls back to a rules-only diagnosis rather than crashing or silently accepting bad data. `requires_human_review` is force-set to `true` regardless of what the model returns.

## Human Review

Every diagnosis (AI-assisted or rules-only) is created with status `PENDING_REVIEW`. A human reviewer must:
- **Approve** — accepts the diagnosis and proposed fix as-is (never executes it — simulated only)
- **Edit** — modifies the proposed Cisco commands before approving; both original and edited versions are stored
- **Reject** — rejects the diagnosis outright with a required reason, logged as an AI correction

A diagnosis can only be reviewed once.

## Audit Logging

Every rule check, AI diagnosis, and review decision is written to the `audit_logs` table and viewable at `/api/audit` or the Audit Log page. See [`docs/model_audit_log.md`](docs/model_audit_log.md) for the full event taxonomy and safety invariants.

## Demo

Click **"Run Demo Case"** on the Dashboard or the Troubleshoot Case page. It loads case `NET-001` (a VLAN sub-interface administratively down), automatically runs the rule checker and AI diagnosis, and drops you into the review panel — walk through Approve/Edit/Reject and then run the simulated verification to see the complete pipeline.

---

## Running Tests

```bash
cd backend
pytest tests/ -v
```

The suite covers: rule-checker determinism and pattern detection, case CRUD and validation, the diagnose endpoint's graceful no-API-key fallback, the full review workflow (approve/edit/reject, the double-review guard, audit trail), the AI engine's handling of invalid/malformed LLM output (via a mocked provider — no real API key needed), and live analytics computation. The Streamlit frontend has no separate automated test suite — it's a thin presentation layer over the backend API, so backend test coverage is where the correctness guarantees live.

---

## Notes on Safety

- NetSage AI **never** executes a Cisco configuration command against any real or virtual device, at any point, under any review decision.
- All "deployment" and "verification" actions in the Approve flow are explicitly simulated and labeled as such in both the UI and audit log.
- Missing or invalid `OPENAI_API_KEY`, malformed LLM responses, and LLM API failures all degrade gracefully to a rules-only diagnosis rather than crashing the application.

## A note on the frontend choice

This project originally shipped a React/Vite frontend and was later rebuilt with Streamlit instead, at the project owner's request — both talk to the exact same unchanged FastAPI backend over the same REST API. Streamlit trades some UI polish (no true modal dialogs, less granular layout control, Streamlit's rerun-on-interaction model instead of fine-grained React state) for a much simpler Python-only stack with no separate Node/npm toolchain to install or maintain.
