# NetSage AI — Model Audit Log

This document describes how NetSage AI tracks every AI-assisted diagnosis
and the human decisions made about it. The live, queryable version of this
log is available at `GET /api/audit` and in the **Audit Log** page of the
dashboard; this file documents the *design* of that system.

## Design principle

> **AI proposes → Rule Checker validates → Human reviews → Human
> approves/rejects → Action is logged.**

No diagnosis is ever considered "final" or actionable until a human
reviewer has explicitly recorded a decision. No step in this pipeline
executes a real Cisco configuration command.

## What gets logged

Every one of the following events creates an immutable row in the
`audit_logs` table:

| Event type                     | When it fires                                                    |
|---------------------------------|-------------------------------------------------------------------|
| `DATASET_SEEDED`               | On first application boot, when the 30-case dataset is loaded     |
| `CASE_CREATED`                 | A user creates a custom troubleshooting case                      |
| `RULE_CHECK_RUN`               | The deterministic rule checker runs against a case                |
| `AI_DIAGNOSIS_CREATED`         | The AI engine successfully returns a structured diagnosis         |
| `RULES_ONLY_DIAGNOSIS_CREATED` | AI was unavailable/failed; a rule-checker-only record was created |
| `REVIEW_APPROVED`              | A human reviewer approves a diagnosis's proposed fix               |
| `REVIEW_EDITED`                | A human reviewer edits the proposed Cisco commands                 |
| `REVIEW_REJECTED`              | A human reviewer rejects the AI diagnosis                          |
| `VERIFICATION_RUN`             | A simulated before/after verification is generated post-approval  |

Each row stores: `case_id`, `diagnosis_id` (where applicable), `event_type`,
a JSON `details` payload specific to that event, and a `timestamp`.

## Review decision statuses

A `Diagnosis` always carries one of the following statuses:

- `PENDING_REVIEW` — AI (or rules-only) diagnosis exists, awaiting a human.
- `ACCEPTED` — a human reviewer approved the diagnosis and proposed fix as-is.
- `EDITED` — a human reviewer approved the diagnosis but modified the
  proposed Cisco commands before approving.
- `REJECTED` — a human reviewer rejected the AI's diagnosis outright.

## Responsible AI corrections

A subset of dataset cases are specifically designed to demonstrate the AI
being naturally or intentionally corrected by a human reviewer. See
[`docs/responsible_ai_log.md`](./responsible_ai_log.md) for the running list
of such corrections, why the AI's initial read was wrong, and the lesson
learned from each one.

## Safety invariants enforced at the code level

1. `AIDiagnosisPayload.requires_human_review` is force-validated to `True`
   by a Pydantic field validator — no LLM output can ever waive review.
2. `Diagnosis.requires_human_review` is independently hardcoded to `1` at
   the database layer, regardless of what the AI engine returned.
3. `review_service.py` refuses to let a `Diagnosis` be reviewed twice — a
   diagnosis with an existing `Review` row raises `ReviewError`.
4. Approval **never** executes any command. `REVIEW_APPROVED` audit entries
   explicitly note: *"Simulated only — no commands were executed against
   any real or virtual device."*
