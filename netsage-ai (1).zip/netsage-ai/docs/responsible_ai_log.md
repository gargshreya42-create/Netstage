# NetSage AI — Responsible AI Log

This log documents cases where a human reviewer's decision diverged from
what the AI engine would most plausibly propose, why the divergence makes
sense, and what it teaches about the AI's limitations. These are used as
worked examples during onboarding/demo and to calibrate expectations for
the AI Agreement Rate shown on the Analytics page.

Unlike the live `audit_logs` table (which records whatever a real reviewer
actually decides at runtime), this file is a curated reference set —
representative scenarios the platform is designed to handle correctly,
written up in the same case/diagnosis/correction/lesson format a real
review would produce.

---

## Case NET-004 — Missing static route

**AI diagnosis (plausible):** "Routing problem — likely an incorrect route
or route metric issue between Branch and HQ."

**Human correction:** No route exists at all (not just a wrong one) — the
router has zero static routes configured toward HQ. The reviewer edited the
fix to add the specific missing route rather than accept a vaguer "check
routing" recommendation.

**Why the AI's framing needed correction:** Evidence showed `(no route to
192.168.1.0/24)` in `show ip route`, and an empty static-route
configuration. A generic "routing problem" diagnosis, without pinpointing
*which* route is absent, is not actionable enough for a junior engineer.

**Lesson learned:** Diagnoses should name the exact missing/incorrect route
whenever the evidence contains it, not just categorize the fault type.

---

## Case NET-006 — NAT interfaces not marked

**AI diagnosis (plausible):** "NAT overload configuration appears
incorrect — recommend re-checking the ACL."

**Human correction:** Rejected the ACL-focused framing. The ACL (`permit
10.0.0.0 0.0.0.255`) was actually correct; the real fault was that neither
interface was marked `ip nat inside` / `ip nat outside`, so NAT never
triggered regardless of the ACL.

**Why the AI's framing needed correction:** The AI over-indexed on the ACL
because it's the most commonly misconfigured NAT element, without checking
whether the interfaces were marked at all.

**Lesson learned:** When multiple NAT components are present, check each
independently against the evidence rather than defaulting to the
statistically most common misconfiguration.

---

## Case NET-013 — Floating static route treated as a simple routing fix

**AI diagnosis (plausible):** "Backup route configuration is broken;
recommend removing and re-adding the backup static route."

**Human correction:** Edited the proposed fix. The real issue is that the
backup route was configured with the *same* administrative distance as the
primary route (both AD 1), so it isn't actually a floating backup — it
needs a higher AD (e.g. `ip route 192.168.1.0 255.255.255.0 10.0.1.1 5`),
not a removal/re-add.

**Why the AI's framing needed correction:** "Remove and re-add" does not
fix an AD misconfiguration; it just recreates the same problem. The
reviewer's edit corrected the specific technical cause (equal AD → no true
failover).

**Lesson learned:** For redundancy/failover scenarios, verify AD, metric,
or priority values before recommending a reconfiguration — the *values*
matter more than the *existence* of the configuration.

---

## Case NET-018 — ACL diagnosis correctly scoped to Layer 4, not Layer 3

**AI diagnosis (plausible, if under-evidenced):** "Routing or DNS issue —
internal sites unreachable by name."

**Human correction:** Rejected an initial routing-focused hypothesis in
favor of the ACL evidence: `deny tcp any any eq 80` and `eq 443` are
explicit in ACL 110. The reviewer confirmed the fault is Layer 4 (blocked
TCP ports), not Layer 3 routing or Layer 7 DNS, since DNS resolution and
non-web protocols (445, 22) were confirmed working.

**Why the AI's framing needed correction:** Symptom text ("browsing...
times out") superficially resembles a DNS or connectivity problem, but the
rule-checker evidence pointed specifically at blocked HTTP/HTTPS ports.

**Lesson learned:** Symptom wording can bias initial hypotheses toward the
wrong OSI layer; the rule-checker's structured evidence should always take
precedence over surface-level symptom phrasing.

---

## Case NET-025 — DNS diagnosis needed more specific corrective action

**AI diagnosis (plausible):** "DNS server misconfigured — recommend adding
a name-server entry."

**Human correction:** Edited the fix. The server already has an external
`ip name-server 8.8.8.8` entry and correctly resolves external names — the
actual gap is the *absence of an authoritative local zone* for
`corp.local`. The reviewer replaced the proposed fix with the correct
zone/host-entry configuration rather than another external name-server
entry.

**Why the AI's framing needed correction:** "DNS misconfigured" is too
broad; the evidence shows external DNS working perfectly, isolating the
fault to the missing internal zone specifically.

**Lesson learned:** When evidence shows partial functionality (external
resolution works, internal doesn't), the diagnosis and fix must target the
specific missing piece, not the DNS subsystem as a whole.

---

## Summary

| Case    | AI's initial framing           | Human correction                          | Root issue                        |
|---------|----------------------------------|--------------------------------------------|------------------------------------|
| NET-004 | Generic "routing problem"       | Named the exact missing route              | Under-specific diagnosis          |
| NET-006 | Blamed the ACL                  | Correctly identified NAT interface marking | Wrong component blamed            |
| NET-013 | "Remove and re-add" route       | Fixed the administrative distance value    | Wrong fix for right symptom        |
| NET-018 | Leaned toward routing/DNS       | Correctly scoped to Layer 4 ACL             | OSI layer misattribution          |
| NET-025 | Generic "DNS misconfigured"     | Isolated to missing authoritative zone     | Under-specific diagnosis          |

These five corrections directly inform the **AI Agreement Rate** metric on
the Analytics page (`Accepted / Reviewed × 100`) — a healthy platform
should show a meaningful share of `EDITED` and occasional `REJECTED`
outcomes, not 100% blind acceptance of AI output.
