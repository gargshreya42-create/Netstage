# NetSage AI — Architecture

## Design principle

> **AI proposes → Rule Checker validates → Human reviews → Human approves/rejects → Action is logged.**

Every architectural decision in this project traces back to that sentence. Nothing is allowed to skip a step.

## Request flow

```
┌─────────────┐      ┌──────────────────┐      ┌────────────────────┐
│   Frontend   │──1──▶│   FastAPI Backend │──2──▶│  Deterministic Rule │
│   Streamlit  │      │                    │      │  Checker (checker.py)│
└─────────────┘      │                    │      └────────────────────┘
       ▲              │                    │──3──▶┌────────────────────┐
       │              │                    │      │   AI Diagnosis      │
       │              │                    │      │   Engine (engine.py) │
       │              │                    │      │   via AIProvider      │
       │              │                    │      └────────────────────┘
       │              │                    │──4──▶┌────────────────────┐
       └──────7───────│                    │      │  SQLite Database     │
                       │                    │      │  (cases, diagnoses,   │
                       │                    │◀──5──│   reviews, audit_logs) │
                       └──────────────────┘      └────────────────────┘
                              ▲
                              │ 6. Human reviewer calls
                              │    /api/reviews/{id}/approve|edit|reject
```

1. User selects/creates a case and requests diagnosis.
2. Backend loads the case and runs the deterministic rule checker first — this never depends on the LLM.
3. If AI is enabled (`OPENAI_API_KEY` configured) and requested, the backend builds a prompt from the case evidence + rule-checker results and calls the configured `AIProvider`.
4. The response is validated against `AIDiagnosisPayload` and persisted as a `Diagnosis` row with `status=PENDING_REVIEW`.
5. Every step (rule check, diagnosis creation, and later, review decisions) writes an `AuditLog` row.
6. A human reviewer calls Approve, Edit, or Reject. This is the only way a `Diagnosis.status` can change out of `PENDING_REVIEW`.
7. The frontend reflects the latest state; nothing is pushed to a real or simulated network device at any point.

## Why a provider abstraction for AI

`app/ai/provider.py` defines an abstract `AIProvider` with a single `complete(system_prompt, user_prompt) -> str` method. `OpenAIProvider` is the only concrete implementation today, but the rest of the app (`engine.py`, `diagnosis_service.py`) never imports the OpenAI SDK directly. Swapping to a different vendor, or adding a local/self-hosted model, means writing one new subclass — no changes needed anywhere else.

## Why rules and AI are separate modules

`app/rules/checker.py` has zero imports from `app/ai/`. This is intentional: the rule checker must be reproducible and auditable independent of any LLM's availability, cost, or non-determinism. It also acts as **grounding context** fed into the AI prompt, so the AI's reasoning is anchored to something deterministic rather than working from raw evidence alone.

## Why SQLite (and how it stays Postgres-ready)

The spec calls for SQLite in the initial implementation with an eye toward PostgreSQL later. `app/database/session.py` builds its engine from a single `DATABASE_URL` setting; the only SQLite-specific code is a one-line `connect_args` guard for the `check_same_thread` flag. Switching to Postgres is: change `DATABASE_URL` in `.env`, `pip install psycopg2-binary`, done — no model or query code changes.

## Safety invariants and where they live

| Invariant | Enforced in |
|---|---|
| AI output can never waive human review | `AIDiagnosisPayload.requires_human_review` field validator (`schemas/diagnosis_schemas.py`) |
| DB-level diagnosis always requires review | `Diagnosis.requires_human_review` hardcoded at creation (`services/diagnosis_service.py`) |
| A diagnosis can't be reviewed twice | `review_service._get_diagnosis_or_raise` |
| Approval never executes a command | No code path in `review_service.py` or `verification_service.py` sends network commands anywhere; approval only writes DB rows and an audit entry explicitly noting the action was simulated |
| Malformed/invalid AI output never crashes the app | `ai/engine.py` catches JSON/schema failures and raises `AIEngineError`, which `diagnosis_service.py` catches and falls back to a rules-only diagnosis |
| Missing API key never crashes the app | `Settings.ai_enabled` checked before any provider call; same fallback path as above |
| Unexpected/DB errors never crash the app | Global `Exception` handler in `main.py` returns a clean 500 instead of propagating a traceback |

## Frontend structure

The frontend is a Streamlit multi-page app — Python-only, no Node/npm toolchain. `streamlit_app/Dashboard.py` is the entrypoint; every file in `streamlit_app/pages/` becomes a sidebar nav entry automatically (Streamlit derives the label from the filename). Shared logic lives in `streamlit_app/lib/`:
- `api_client.py` — every backend call goes through here (mirrors the full REST API 1:1)
- `styling.py` — CSS injected via `st.markdown(unsafe_allow_html=True)`, carrying over the same NOC/terminal design tokens (colors, fonts, badge/status styling) used throughout the project
- `components.py` — reusable render helpers: the syntax-highlighted `TerminalOutput`-equivalent for raw `show`-command evidence, severity/status badges, and hand-built bar-chart rows for the distribution charts

State that needs to persist across a user's interactions within a page (the selected case, rule-checker results, the in-progress diagnosis, review decision, verification result) lives in `st.session_state`, which Streamlit shares across all pages in a session — this is what lets "Open" buttons on the Case Library, AI Diagnoses, and Review Queue pages jump straight to the Troubleshoot Case page with the right case pre-loaded.

Streamlit reruns the entire page script on every interaction rather than doing fine-grained DOM diffing, so the pages are written as straight-line, top-to-bottom scripts rather than React-style component trees — session state substitutes for what would otherwise be component state.
