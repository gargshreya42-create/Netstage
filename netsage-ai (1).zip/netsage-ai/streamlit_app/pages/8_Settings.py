"""Settings — system status and environment variable reference."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd
import streamlit as st

import lib.api_client as api
from lib.components import page_header
from lib.styling import COLORS, inject_css

st.set_page_config(page_title="NetSage AI — Settings", layout="wide")
inject_css()

page_header(
    "Configuration",
    "Settings",
    "System status and configuration reference. API keys are managed via backend environment variables only.",
)

st.markdown('<div class="ns-panel">', unsafe_allow_html=True)
st.subheader("System Status")

try:
    health = api.health()
    st.markdown(
        f"""
        | | |
        |---|---|
        | Backend | :green[Online] |
        | Service | `{health['service']}` |
        | Environment | `{health['environment']}` |
        | Backend URL | `{api.API_BASE_URL}` |
        | AI Diagnosis Engine | {':green[Enabled (OPENAI_API_KEY configured)]' if health['ai_enabled'] else ':orange[Disabled — rules-only mode]'} |
        """
    )
except api.ApiError:
    st.error(
        f"Could not reach the backend at {api.API_BASE_URL}. Make sure it's running "
        f"(`uvicorn app.main:app --reload` from the `backend/` directory)."
    )

st.markdown("</div>", unsafe_allow_html=True)

st.markdown('<div class="ns-panel">', unsafe_allow_html=True)
st.subheader("Environment Variables Reference")
st.write(
    "Backend variables are set in `backend/.env` (copy from `.env.example`). "
    "The Streamlit frontend itself reads `NETSAGE_API_BASE_URL` (defaults to `http://localhost:8000`) "
    "if you set it as an environment variable before running `streamlit run Dashboard.py`. "
    "Never commit real credentials."
)
df = pd.DataFrame(
    [
        {"Variable": "OPENAI_API_KEY", "Location": "backend/.env", "Purpose": "LLM provider key. Blank = rules-only mode automatically."},
        {"Variable": "AI_MODEL", "Location": "backend/.env", "Purpose": "Model name used for diagnosis calls."},
        {"Variable": "DATABASE_URL", "Location": "backend/.env", "Purpose": "SQLite by default; swappable for PostgreSQL."},
        {"Variable": "CORS_ORIGINS", "Location": "backend/.env", "Purpose": "Comma-separated allowed frontend origins."},
        {"Variable": "NETSAGE_API_BASE_URL", "Location": "shell env (optional)", "Purpose": "Where this Streamlit app looks for the backend."},
    ]
)
st.dataframe(df, use_container_width=True, hide_index=True)
st.markdown("</div>", unsafe_allow_html=True)
