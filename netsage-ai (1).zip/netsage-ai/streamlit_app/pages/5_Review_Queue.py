"""Review Queue — diagnoses awaiting human Approve/Edit/Reject."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import streamlit as st

import lib.api_client as api
from lib.components import page_header, severity_badge_html
from lib.styling import inject_css

st.set_page_config(page_title="NetSage AI — Review Queue", layout="wide")
inject_css()

page_header(
    "Human-in-the-Loop",
    "Review Queue",
    "AI diagnoses awaiting Approve / Edit / Reject. Nothing here has been actioned on the network yet.",
)

try:
    queue = api.get_review_queue()
except api.ApiError as e:
    st.error(str(e))
    queue = []

st.markdown('<div class="ns-panel">', unsafe_allow_html=True)

if not queue:
    st.success("Review queue is empty. Every diagnosis has been reviewed.")
else:
    header = st.columns([1, 3.2, 1, 1, 1.5, 0.8])
    for col, label in zip(header, ["Case", "Root Cause", "Confidence", "Severity", "Submitted", ""]):
        col.markdown(f"**{label}**")

    for d in queue:
        row = st.columns([1, 3.2, 1, 1, 1.5, 0.8])
        row[0].code(d["case_id"])
        row[1].write(d["root_cause"])
        row[2].write(d["confidence"])
        with row[3]:
            st.markdown(severity_badge_html(d["severity"]), unsafe_allow_html=True)
        row[4].caption(d["created_at"][:19].replace("T", " "))
        with row[5]:
            if st.button("Review", key=f"queue_review_{d['id']}"):
                st.session_state["preselect_case_id"] = d["case_id"]
                st.switch_page("pages/1_Troubleshoot_Case.py")

st.markdown("</div>", unsafe_allow_html=True)
