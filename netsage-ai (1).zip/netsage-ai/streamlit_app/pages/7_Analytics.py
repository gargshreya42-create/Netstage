"""Analytics — live metrics computed from the database."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import streamlit as st

import lib.api_client as api
from lib.components import page_header, render_distribution_chart, severity_color
from lib.styling import COLORS, inject_css

st.set_page_config(page_title="NetSage AI — Analytics", layout="wide")
inject_css()

page_header(
    "Metrics",
    "Analytics",
    "Computed live from the database \u2014 AI Agreement Rate = Accepted diagnoses \u00f7 reviewed diagnoses \u00d7 100.",
)

try:
    data = api.get_analytics()
except api.ApiError as e:
    st.error(str(e))
    st.stop()

c1, c2, c3, c4 = st.columns(4)
c1.metric("Total Diagnoses", data["diagnosed_cases"])
c2.metric("Accepted", data["accepted"])
c3.metric("Edited", data["edited"])
c4.metric("Rejected", data["rejected"])

st.markdown('<div class="ns-panel">', unsafe_allow_html=True)
st.subheader("AI Agreement Rate")
reviewed_total = data["accepted"] + data["edited"] + data["rejected"]
st.markdown(
    f'<span style="font-family:\'IBM Plex Mono\',monospace;font-size:42px;font-weight:700;color:{COLORS["accent_ok"]};">'
    f'{data["ai_agreement_rate"]:.1f}%</span> '
    f'<span style="font-size:13px;color:{COLORS["text_dim"]};">'
    f'{data["accepted"]} accepted of {reviewed_total} reviewed</span>',
    unsafe_allow_html=True,
)

if reviewed_total > 0:
    accepted_pct = data["accepted"] / reviewed_total * 100
    edited_pct = data["edited"] / reviewed_total * 100
    rejected_pct = data["rejected"] / reviewed_total * 100
    st.markdown(
        f"""
        <div style="margin-top:16px;background:#060a13;border-radius:8px;height:14px;overflow:hidden;display:flex;">
            <div style="width:{accepted_pct}%;background:{COLORS['accent_ok']};" title="Accepted"></div>
            <div style="width:{edited_pct}%;background:{COLORS['accent_ai']};" title="Edited"></div>
            <div style="width:{rejected_pct}%;background:{COLORS['sev_critical']};" title="Rejected"></div>
        </div>
        <div style="display:flex;gap:18px;margin-top:10px;font-size:12px;">
            <span style="color:{COLORS['text_secondary']};">
                <span style="display:inline-block;width:8px;height:8px;border-radius:2px;background:{COLORS['accent_ok']};margin-right:6px;"></span>Accepted
            </span>
            <span style="color:{COLORS['text_secondary']};">
                <span style="display:inline-block;width:8px;height:8px;border-radius:2px;background:{COLORS['accent_ai']};margin-right:6px;"></span>Edited
            </span>
            <span style="color:{COLORS['text_secondary']};">
                <span style="display:inline-block;width:8px;height:8px;border-radius:2px;background:{COLORS['sev_critical']};margin-right:6px;"></span>Rejected
            </span>
        </div>
        """,
        unsafe_allow_html=True,
    )
st.markdown("</div>", unsafe_allow_html=True)

col_a, col_b = st.columns(2)
with col_a:
    st.markdown('<div class="ns-panel">', unsafe_allow_html=True)
    st.subheader("Issue Distribution")
    render_distribution_chart(data["issue_type_distribution"])
    st.markdown("</div>", unsafe_allow_html=True)
with col_b:
    st.markdown('<div class="ns-panel">', unsafe_allow_html=True)
    st.subheader("Severity Distribution")
    render_distribution_chart(data["severity_distribution"], color_fn=severity_color)
    st.markdown("</div>", unsafe_allow_html=True)
