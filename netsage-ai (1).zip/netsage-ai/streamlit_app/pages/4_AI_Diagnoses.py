"""AI Diagnoses — every diagnosis the AI engine has proposed, with review status."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import streamlit as st

import lib.api_client as api
from lib.components import page_header, severity_badge_html, status_badge_html
from lib.styling import inject_css

st.set_page_config(page_title="NetSage AI — AI Diagnoses", layout="wide")
inject_css()

page_header(
    "AI Engine Output",
    "AI Diagnoses",
    "Every diagnosis the AI engine has proposed, alongside its current review status.",
)

STATUSES = ["", "PENDING_REVIEW", "ACCEPTED", "EDITED", "REJECTED"]

st.markdown('<div class="ns-panel">', unsafe_allow_html=True)
status = st.selectbox("Status", STATUSES, format_func=lambda x: x.replace("_", " ") if x else "All statuses")
st.markdown("</div>", unsafe_allow_html=True)

try:
    diagnoses = api.list_diagnoses(status=status)
except api.ApiError as e:
    st.error(str(e))
    diagnoses = []

st.markdown('<div class="ns-panel">', unsafe_allow_html=True)

if not diagnoses:
    st.info("No diagnoses yet. Run a diagnosis from the Troubleshoot Case page to see it here.")
else:
    header = st.columns([1, 3.5, 1, 1, 1.3, 0.8])
    for col, label in zip(header, ["Case", "Root Cause", "Confidence", "Severity", "Status", ""]):
        col.markdown(f"**{label}**")

    for d in diagnoses:
        row = st.columns([1, 3.5, 1, 1, 1.3, 0.8])
        row[0].code(d["case_id"])
        row[1].write(d["root_cause"])
        row[2].write(d["confidence"])
        with row[3]:
            st.markdown(severity_badge_html(d["severity"]), unsafe_allow_html=True)
        with row[4]:
            st.markdown(status_badge_html(d["status"]), unsafe_allow_html=True)
        with row[5]:
            if st.button("Open", key=f"diag_open_{d['id']}"):
                st.session_state["preselect_case_id"] = d["case_id"]
                st.switch_page("pages/1_Troubleshoot_Case.py")

st.markdown("</div>", unsafe_allow_html=True)
