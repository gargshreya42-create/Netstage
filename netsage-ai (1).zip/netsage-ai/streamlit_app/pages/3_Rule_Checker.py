"""Standalone Rule Checker — run the deterministic engine in isolation, no AI call."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd
import streamlit as st

import lib.api_client as api
from lib.components import page_header
from lib.styling import COLORS, inject_css

st.set_page_config(page_title="NetSage AI — Rule Checker", layout="wide")
inject_css()

page_header(
    "Deterministic Engine",
    "Rule Checker",
    "Run the regex-based deterministic checks in isolation, without invoking the AI engine. "
    "Always reproducible, never LLM-dependent.",
)

try:
    case_list = api.list_cases()
except api.ApiError as e:
    st.error(str(e))
    case_list = []

labels = {"": "Select a case..."}
for c in case_list:
    labels[c["case_id"]] = f"{c['case_id']} \u2014 {c['symptom'][:60]}"

st.markdown('<div class="ns-panel">', unsafe_allow_html=True)
col1, col2 = st.columns([4, 1])
with col1:
    case_id = st.selectbox(
        "Case", [""] + [c["case_id"] for c in case_list], format_func=lambda x: labels.get(x, x),
        label_visibility="collapsed",
    )
with col2:
    run_clicked = st.button("Run Rule Checker", type="primary", use_container_width=True, disabled=not case_id)
st.markdown("</div>", unsafe_allow_html=True)

if run_clicked and case_id:
    try:
        result = api.check_rules(case_id)
        st.session_state["rc_result"] = result
        st.session_state["rc_case_id"] = case_id
    except api.ApiError as e:
        st.error(str(e))

result = st.session_state.get("rc_result")
if result and st.session_state.get("rc_case_id") == case_id:
    st.markdown('<div class="ns-panel">', unsafe_allow_html=True)
    c1, c2 = st.columns([4, 1])
    with c1:
        st.subheader(f"Result \u2014 {case_id}")
    with c2:
        color = COLORS["sev_high"] if result["status"] == "ERRORS_DETECTED" else COLORS["accent_ok"]
        st.markdown(
            f'<span style="color:{color};font-family:\'IBM Plex Mono\',monospace;">{result["status"].replace("_"," ")}</span>',
            unsafe_allow_html=True,
        )

    if not result["errors"]:
        st.info(
            "No deterministic errors detected. This doesn't mean the case is healthy \u2014 it means no known "
            "pattern matched. Try running the full AI diagnosis for cases like this."
        )
    else:
        df = pd.DataFrame(
            [
                {
                    "Type": e["type"],
                    "Interface": e.get("interface") or "\u2014",
                    "Severity": e["severity"].title(),
                    "Evidence": e["evidence"],
                }
                for e in result["errors"]
            ]
        )
        st.dataframe(df, use_container_width=True, hide_index=True)
    st.markdown("</div>", unsafe_allow_html=True)
