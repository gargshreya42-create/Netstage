"""Audit Log — every rule check, AI diagnosis, and human review decision."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import json

import pandas as pd
import streamlit as st

import lib.api_client as api
from lib.components import page_header
from lib.styling import inject_css

st.set_page_config(page_title="NetSage AI — Audit Log", layout="wide")
inject_css()

page_header(
    "Responsible AI",
    "Audit Log",
    "Every rule check, AI diagnosis, and human review decision \u2014 nothing in NetSage AI happens off the record.",
)

EVENT_TYPES = [
    "", "DATASET_SEEDED", "CASE_CREATED", "RULE_CHECK_RUN", "AI_DIAGNOSIS_CREATED",
    "RULES_ONLY_DIAGNOSIS_CREATED", "REVIEW_APPROVED", "REVIEW_EDITED", "REVIEW_REJECTED", "VERIFICATION_RUN",
]

st.markdown('<div class="ns-panel">', unsafe_allow_html=True)
c1, c2 = st.columns(2)
with c1:
    case_id = st.text_input("Case ID", placeholder="e.g. NET-001")
with c2:
    event_type = st.selectbox("Event Type", EVENT_TYPES, format_func=lambda x: x.replace("_", " ") if x else "All events")
st.markdown("</div>", unsafe_allow_html=True)

try:
    entries = api.get_audit_log(case_id=case_id or None, event_type=event_type or None)
except api.ApiError as e:
    st.error(str(e))
    entries = []

st.markdown('<div class="ns-panel">', unsafe_allow_html=True)

if not entries:
    st.info("No audit entries match. Try clearing the filters.")
else:
    df = pd.DataFrame(
        [
            {
                "Timestamp": e["timestamp"][:19].replace("T", " "),
                "Case": e["case_id"],
                "Event": e["event_type"],
                "Details": json.dumps(e.get("details") or {}),
            }
            for e in entries
        ]
    )
    st.dataframe(df, use_container_width=True, hide_index=True, height=560)

st.markdown("</div>", unsafe_allow_html=True)
