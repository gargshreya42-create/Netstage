"""
Troubleshoot Case — the core NetSage AI workflow:
select/create a case -> view evidence -> run rule checker -> run AI
diagnosis -> human review (Approve/Edit/Reject) -> simulated verification.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import streamlit as st

import lib.api_client as api
from lib.components import (
    human_review_banner,
    page_header,
    render_terminal_output,
    severity_badge_html,
    status_badge_html,
)
from lib.styling import COLORS, inject_css

import pandas as pd

st.set_page_config(page_title="NetSage AI — Troubleshoot Case", layout="wide")
inject_css()

DEMO_CASE_ID = "NET-001"
CONCEPT_TAGS = ["VLAN", "Gateway", "DHCP", "DNS", "Routing", "ACL", "NAT", "Wireless"]
SEVERITIES = ["Low", "Medium", "High", "Critical"]

# --- Session state defaults ---
for key, default in [
    ("ts_case_id", None),
    ("ts_case_detail", None),
    ("ts_rule_result", None),
    ("ts_diagnosis", None),
    ("ts_review", None),
    ("ts_verification", None),
    ("ts_show_edit", False),
    ("ts_show_reject", False),
]:
    if key not in st.session_state:
        st.session_state[key] = default


def reset_workflow():
    st.session_state.ts_rule_result = None
    st.session_state.ts_diagnosis = None
    st.session_state.ts_review = None
    st.session_state.ts_verification = None
    st.session_state.ts_show_edit = False
    st.session_state.ts_show_reject = False


def load_case(case_id):
    try:
        detail = api.get_case(case_id)
    except api.ApiError as e:
        st.error(str(e))
        return
    reset_workflow()
    st.session_state.ts_case_id = case_id
    st.session_state.ts_case_detail = detail


def run_rule_check(case_id):
    try:
        result = api.check_rules(case_id)
        st.session_state.ts_rule_result = result
        return result
    except api.ApiError as e:
        st.error(str(e))
        return None


def run_diagnose(case_id):
    try:
        result = api.diagnose(case_id, force_ai=True)
        st.session_state.ts_diagnosis = result
        st.success("Diagnosis complete \u2014 awaiting human review.")
        return result
    except api.ApiError as e:
        st.error(str(e))
        return None


def run_full_diagnosis(case_id):
    run_rule_check(case_id)
    run_diagnose(case_id)


page_header(
    "Workflow",
    "Troubleshoot Case",
    "AI proposes a diagnosis \u2192 the rule checker validates it \u2192 a human reviewer approves, edits, or rejects it.",
)

# --- Handle "Run Demo Case" trigger from the Dashboard ---
if st.session_state.get("run_demo"):
    st.session_state["run_demo"] = False
    load_case(DEMO_CASE_ID)
    st.info("Demo case loaded. Running rule checker and AI diagnosis...")
    run_full_diagnosis(DEMO_CASE_ID)

# --- Handle a case selected from Case Library / Review Queue / AI Diagnoses ---
if st.session_state.get("preselect_case_id"):
    preselect = st.session_state.pop("preselect_case_id")
    load_case(preselect)

# --- Step 1: Select or create a case ---
st.markdown('<div class="ns-panel">', unsafe_allow_html=True)
st.subheader("Step 1 \u00b7 Select or Create a Case")

mode = st.radio("Mode", ["Existing Case", "Custom Case"], horizontal=True, label_visibility="collapsed")

if mode == "Existing Case":
    try:
        case_list = api.list_cases()
    except api.ApiError as e:
        st.error(str(e))
        case_list = []

    options = [""] + [c["case_id"] for c in case_list]
    labels = {"": "Select a case..."}
    for c in case_list:
        labels[c["case_id"]] = f"{c['case_id']} \u2014 {c['symptom'][:60]}"

    col1, col2 = st.columns([4, 1])
    with col1:
        default_index = options.index(st.session_state.ts_case_id) if st.session_state.ts_case_id in options else 0
        chosen = st.selectbox(
            "Case", options, index=default_index, format_func=lambda x: labels.get(x, x), label_visibility="collapsed"
        )
    with col2:
        if st.button("Run Demo Case", use_container_width=True):
            load_case(DEMO_CASE_ID)
            run_full_diagnosis(DEMO_CASE_ID)
            st.rerun()

    if chosen and chosen != st.session_state.ts_case_id:
        load_case(chosen)
        st.rerun()

else:
    with st.form("custom_case_form"):
        symptom = st.text_input("Symptom *", placeholder="e.g. PC1 cannot reach Server2")
        topology_note = st.text_input("Topology Note", placeholder="Relevant topology context")
        show_outputs = st.text_area(
            "Show-Command Output *", placeholder="R1# show interfaces GigabitEthernet0/1\n...", height=150
        )
        col1, col2 = st.columns(2)
        with col1:
            concept_tag = st.selectbox("Concept / Issue Type", CONCEPT_TAGS)
        with col2:
            severity = st.selectbox("Severity", SEVERITIES, index=1)
        submitted = st.form_submit_button("Create Case", type="primary")

        if submitted:
            if not symptom.strip() or not show_outputs.strip():
                st.warning("Symptom and show-command output are required.")
            else:
                try:
                    created = api.create_case(
                        {
                            "symptom": symptom,
                            "topology_note": topology_note,
                            "show_outputs": show_outputs,
                            "concept_tag": concept_tag,
                            "severity": severity,
                        }
                    )
                    st.success(f"Custom case {created['case_id']} created.")
                    load_case(created["case_id"])
                    st.rerun()
                except api.ApiError as e:
                    st.error(str(e))

st.markdown("</div>", unsafe_allow_html=True)

# --- Case detail + evidence + rule checker + diagnosis ---
case_detail = st.session_state.ts_case_detail

if case_detail:
    st.markdown('<div class="ns-panel">', unsafe_allow_html=True)
    col1, col2 = st.columns([5, 1])
    with col1:
        st.subheader(case_detail["case_id"])
    with col2:
        st.markdown(severity_badge_html(case_detail["severity"]), unsafe_allow_html=True)

    c1, c2 = st.columns(2)
    with c1:
        st.caption("Symptom")
        st.write(case_detail["symptom"])
    with c2:
        st.caption("Topology Notes")
        st.write(case_detail.get("topology_note") or "\u2014")

    st.caption(
        f"Concept: **{case_detail['concept_tag']}**  \u00b7  OSI Layer: **{case_detail.get('osi_layer') or '\u2014'}**"
    )

    st.markdown("**Step 2 \u00b7 Evidence**")
    render_terminal_output(case_detail["show_outputs"], title=f"{case_detail['case_id']} \u2014 show command output")

    col1, col2 = st.columns(2)
    with col1:
        if st.button("Run Rule Checker", use_container_width=True):
            run_rule_check(case_detail["case_id"])
            st.rerun()
    with col2:
        if st.button("Run Full Diagnosis (Rules + AI)", type="primary", use_container_width=True):
            run_full_diagnosis(case_detail["case_id"])
            st.rerun()

    st.markdown("</div>", unsafe_allow_html=True)

    # --- Rule checker results ---
    rule_result = st.session_state.ts_rule_result
    if rule_result:
        st.markdown('<div class="ns-panel">', unsafe_allow_html=True)
        col1, col2 = st.columns([4, 1])
        with col1:
            st.subheader("Deterministic Rule Checker")
        with col2:
            color = COLORS["sev_high"] if rule_result["status"] == "ERRORS_DETECTED" else COLORS["accent_ok"]
            st.markdown(
                f'<span style="color:{color};font-family:\'IBM Plex Mono\',monospace;font-size:12px;">'
                f'{rule_result["status"].replace("_", " ")}</span>',
                unsafe_allow_html=True,
            )

        if not rule_result["errors"]:
            st.write("No deterministic pattern matched. This case may need AI-level reasoning.")
        else:
            df = pd.DataFrame(
                [
                    {
                        "Type": e["type"],
                        "Interface": e.get("interface") or "\u2014",
                        "Severity": e["severity"].title(),
                        "Evidence": e["evidence"],
                    }
                    for e in rule_result["errors"]
                ]
            )
            st.dataframe(df, use_container_width=True, hide_index=True)
        st.markdown("</div>", unsafe_allow_html=True)

    # --- AI Diagnosis + Human Review ---
    diagnosis = st.session_state.ts_diagnosis
    if diagnosis:
        st.markdown(
            f'<div class="ns-panel" style="border-color:{COLORS["accent_ai"]};">', unsafe_allow_html=True
        )
        col1, col2 = st.columns([4, 1])
        with col1:
            st.subheader("AI Diagnosis")
        with col2:
            st.markdown(status_badge_html(diagnosis["status"]), unsafe_allow_html=True)

        c1, c2 = st.columns(2)
        with c1:
            st.caption("Root Cause")
            st.write(diagnosis["root_cause"])
        with c2:
            st.caption("Reasoning")
            st.write(diagnosis["reasoning"])

        m1, m2, m3, m4 = st.columns(4)
        m1.metric("OSI Layer", diagnosis.get("osi_layer") or "\u2014")
        m2.metric("Confidence", diagnosis["confidence"])
        with m3:
            st.caption("SEVERITY")
            st.markdown(severity_badge_html(diagnosis["severity"]), unsafe_allow_html=True)
        m4.metric("Source", "AI + Rules" if diagnosis["source"] == "ai" else "Rules Only")

        st.caption("Evidence Cited")
        for e in diagnosis["evidence"]:
            st.markdown(f"- {e}")

        if diagnosis.get("next_command"):
            st.caption("Recommended Next Command")
            st.code(diagnosis["next_command"], language="text")

        st.caption("Proposed Fix Steps")
        if not diagnosis["fix_steps"]:
            st.write("No fix proposed \u2014 more evidence needed first.")
        else:
            render_terminal_output("\n".join(diagnosis["fix_steps"]), title="proposed Cisco commands (NOT executed)")

        human_review_banner()

        reviewed = diagnosis["status"] != "PENDING_REVIEW"

        if not reviewed:
            b1, b2, b3 = st.columns(3)
            with b1:
                if st.button("Approve", type="primary", use_container_width=True, key="approve_btn"):
                    try:
                        review = api.approve_diagnosis(diagnosis["id"])
                        st.session_state.ts_review = review
                        st.session_state.ts_diagnosis["status"] = "ACCEPTED"
                        st.success("Diagnosis approved. Fix steps recorded \u2014 no commands were executed.")
                        st.rerun()
                    except api.ApiError as e:
                        st.error(str(e))
            with b2:
                if st.button("Edit", use_container_width=True, key="edit_btn"):
                    st.session_state.ts_show_edit = True
                    st.rerun()
            with b3:
                if st.button("Reject", use_container_width=True, key="reject_btn"):
                    st.session_state.ts_show_reject = True
                    st.rerun()

            if st.session_state.ts_show_edit:
                with st.form("edit_form"):
                    st.markdown("**Edit Proposed Commands**")
                    st.caption(
                        "Modify the Cisco commands before approving. One command per line. Both the original "
                        "AI commands and your edited version are recorded."
                    )
                    edited_text = st.text_area(
                        "Edited commands (one per line)",
                        value="\n".join(diagnosis["fix_steps"]),
                        height=140,
                    )
                    ec1, ec2 = st.columns(2)
                    with ec1:
                        cancel = st.form_submit_button("Cancel")
                    with ec2:
                        confirm = st.form_submit_button("Save Edited Commands", type="primary")

                    if cancel:
                        st.session_state.ts_show_edit = False
                        st.rerun()
                    if confirm:
                        commands = [l.strip() for l in edited_text.split("\n") if l.strip()]
                        if not commands:
                            st.warning("Enter at least one command.")
                        else:
                            try:
                                review = api.edit_diagnosis(diagnosis["id"], commands)
                                st.session_state.ts_review = review
                                st.session_state.ts_diagnosis["status"] = "EDITED"
                                st.session_state.ts_show_edit = False
                                st.success("Edited commands saved and recorded for review.")
                                st.rerun()
                            except api.ApiError as e:
                                st.error(str(e))

            if st.session_state.ts_show_reject:
                with st.form("reject_form"):
                    st.markdown("**Reject AI Diagnosis**")
                    st.caption(
                        "This will be recorded as an AI false positive / incorrect diagnosis. "
                        "Please provide a reason."
                    )
                    reason = st.text_area(
                        "Rejection reason", placeholder="e.g. Evidence actually points to an ACL issue, not routing..."
                    )
                    rc1, rc2 = st.columns(2)
                    with rc1:
                        cancel = st.form_submit_button("Cancel")
                    with rc2:
                        confirm = st.form_submit_button("Reject Diagnosis", type="primary")

                    if cancel:
                        st.session_state.ts_show_reject = False
                        st.rerun()
                    if confirm:
                        if not reason.strip():
                            st.warning("A rejection reason is required.")
                        else:
                            try:
                                review = api.reject_diagnosis(diagnosis["id"], reason.strip())
                                st.session_state.ts_review = review
                                st.session_state.ts_diagnosis["status"] = "REJECTED"
                                st.session_state.ts_show_reject = False
                                st.warning("Diagnosis rejected and logged as an AI correction.")
                                st.rerun()
                            except api.ApiError as e:
                                st.error(str(e))
        else:
            review = st.session_state.ts_review
            if review:
                st.markdown("**Review Decision**")
                comment_suffix = f' \u2014 "{review["reviewer_comment"]}"' if review.get("reviewer_comment") else ""
                st.write(f"Recorded as **{diagnosis['status']}**{comment_suffix}")
                if review.get("rejection_reason"):
                    st.markdown(f":red[Reason: {review['rejection_reason']}]")
                if review.get("edited_commands"):
                    st.caption("Edited Commands")
                    render_terminal_output("\n".join(review["edited_commands"]), title="human-edited commands")

            if diagnosis["status"] in ("ACCEPTED", "EDITED"):
                verification = st.session_state.ts_verification
                if not verification:
                    if st.button("Run Verification (Simulated)"):
                        try:
                            v = api.verify_diagnosis(diagnosis["id"])
                            st.session_state.ts_verification = v
                            st.rerun()
                        except api.ApiError as e:
                            st.error(str(e))
                else:
                    st.markdown(
                        f':green[**{verification["verification_status"]}**]',
                    )
                    vc1, vc2 = st.columns(2)
                    with vc1:
                        st.caption("Before Fix")
                        st.code(
                            f"{verification['before_fix']['command']} \u2192 {verification['before_fix']['result']}",
                            language="text",
                        )
                    with vc2:
                        st.caption("After Fix")
                        st.code(
                            f"{verification['after_fix']['command']} \u2192 {verification['after_fix']['result']}",
                            language="text",
                        )
                    st.caption(verification["note"])

        st.markdown("</div>", unsafe_allow_html=True)
else:
    st.info("Select an existing case, create a custom one, or click **Run Demo Case** to get started.")
