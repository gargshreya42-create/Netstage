"""Case Library — search, filter, and open cases from the dataset."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import streamlit as st

import lib.api_client as api
from lib.components import page_header, severity_badge_html, status_badge_html
from lib.styling import inject_css

st.set_page_config(page_title="NetSage AI — Case Library", layout="wide")
inject_css()

page_header(
    "Dataset",
    "Case Library",
    "Search and filter the troubleshooting case dataset, then open any case to diagnose it.",
)

CONCEPT_TAGS = ["", "VLAN", "Gateway", "DHCP", "DNS", "Routing", "ACL", "NAT", "Wireless"]
SEVERITIES = ["", "Low", "Medium", "High", "Critical"]

st.markdown('<div class="ns-panel">', unsafe_allow_html=True)
c1, c2, c3 = st.columns([2, 1, 1])
with c1:
    search = st.text_input("Search", placeholder="Case ID, symptom, or concept...")
with c2:
    concept_tag = st.selectbox("Issue Type", CONCEPT_TAGS, format_func=lambda x: x or "All types")
with c3:
    severity = st.selectbox("Severity", SEVERITIES, format_func=lambda x: x or "All severities")
st.markdown("</div>", unsafe_allow_html=True)

try:
    cases = api.list_cases(search=search, concept_tag=concept_tag, severity=severity)
except api.ApiError as e:
    st.error(str(e))
    cases = []

st.markdown('<div class="ns-panel">', unsafe_allow_html=True)

if not cases:
    st.info("No matching cases. Try clearing the search or filters.")
else:
    header = st.columns([1.2, 3.5, 1, 1, 1.3, 0.8])
    for col, label in zip(header, ["Case ID", "Symptom", "Type", "Severity", "Diagnosis", ""]):
        col.markdown(f"**{label}**")

    for c in cases:
        row = st.columns([1.2, 3.5, 1, 1, 1.3, 0.8])
        row[0].code(c["case_id"])
        row[1].write(c["symptom"])
        row[2].write(c["concept_tag"])
        with row[3]:
            st.markdown(severity_badge_html(c["severity"]), unsafe_allow_html=True)
        with row[4]:
            if c.get("latest_status"):
                st.markdown(status_badge_html(c["latest_status"]), unsafe_allow_html=True)
            else:
                st.caption("Not run")
        with row[5]:
            if st.button("Open", key=f"open_{c['case_id']}"):
                st.session_state.ts_case_id = None  # force reload on the target page
                st.session_state["preselect_case_id"] = c["case_id"]
                st.switch_page("pages/1_Troubleshoot_Case.py")

st.markdown("</div>", unsafe_allow_html=True)
