"""
NetSage AI — Dashboard (main entrypoint).

Run from the streamlit_app/ directory with: streamlit run Dashboard.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import streamlit as st

import lib.api_client as api
from lib.components import page_header, render_distribution_chart, severity_color, status_pill
from lib.styling import COLORS, inject_css

st.set_page_config(page_title="NetSage AI — Dashboard", layout="wide", initial_sidebar_state="expanded")
inject_css()

# --- Sidebar branding + safety note (shown on every page via this shared block) ---
with st.sidebar:
    st.markdown(
        f"""
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px;">
            <div style="width:32px;height:32px;border-radius:8px;
                 background:linear-gradient(135deg, {COLORS['accent_ai']}, {COLORS['accent_ok']});
                 display:flex;align-items:center;justify-content:center;
                 font-family:'IBM Plex Mono',monospace;font-weight:700;color:#06121f;font-size:14px;">NS</div>
            <div>
                <div style="font-family:'IBM Plex Mono',monospace;font-weight:600;font-size:15px;color:{COLORS['text_primary']};">NetSage AI</div>
                <div style="font-size:10px;color:{COLORS['text_dim']};letter-spacing:0.04em;">AI NETWORK DIAGNOSTIC PLATFORM</div>
            </div>
        </div>
        <hr style="margin:10px 0 14px;">
        """,
        unsafe_allow_html=True,
    )
    st.caption("Human-in-the-loop always required.\nNo commands are executed automatically.")

# --- Header status pills ---
health = api.cached_health()
col1, col2 = st.columns([3, 2])
with col2:
    if health is None:
        status_pill("Backend Offline", COLORS["sev_critical"])
    elif health.get("ai_enabled"):
        status_pill("System Online \u00b7 AI Enabled", COLORS["accent_ok"])
    else:
        status_pill("System Online \u00b7 Rules-Only Mode", COLORS["accent_human"])

if health is None:
    st.error(
        f"Could not reach the backend at {api.API_BASE_URL}. "
        f"Start it with `uvicorn app.main:app --reload` from the `backend/` directory, then reload this page."
    )
    st.stop()

page_header(
    "Overview",
    "Dashboard",
    "Live status across the case library, deterministic rule checker, and AI-assisted review pipeline.",
)

try:
    analytics = api.get_analytics()
except api.ApiError as e:
    st.error(str(e))
    st.stop()

try:
    pending_queue = api.get_review_queue()
    pending_count = len(pending_queue)
except api.ApiError:
    pending_count = analytics.get("pending_review", 0)

status_pill(f"Human Review Required \u00b7 {pending_count} pending", COLORS["accent_human"])
st.write("")

c1, c2, c3, c4 = st.columns(4)
c1.metric("Total Cases", analytics["total_cases"])
c2.metric("Diagnosed Cases", analytics["diagnosed_cases"])
c3.metric("Pending Human Review", analytics["pending_review"])
c4.metric("Critical Issues", analytics["critical_issues"])

c5, c6, c7, c8 = st.columns(4)
c5.metric("Accepted", analytics["accepted"])
c6.metric("Edited", analytics["edited"])
c7.metric("Rejected", analytics["rejected"])
c8.metric("AI Agreement Rate", f"{analytics['ai_agreement_rate']:.0f}%")

st.write("")
col_a, col_b = st.columns(2)
with col_a:
    st.markdown('<div class="ns-panel">', unsafe_allow_html=True)
    st.subheader("Issue Type Distribution")
    render_distribution_chart(analytics["issue_type_distribution"])
    st.markdown("</div>", unsafe_allow_html=True)
with col_b:
    st.markdown('<div class="ns-panel">', unsafe_allow_html=True)
    st.subheader("Severity Distribution")
    render_distribution_chart(analytics["severity_distribution"], color_fn=severity_color)
    st.markdown("</div>", unsafe_allow_html=True)

st.markdown('<div class="ns-panel">', unsafe_allow_html=True)
st.subheader("Quick Actions")
qa1, qa2, qa3, qa4 = st.columns(4)
with qa1:
    if st.button("Start Troubleshooting", type="primary", use_container_width=True):
        st.switch_page("pages/1_Troubleshoot_Case.py")
with qa2:
    if st.button("Open Review Queue", use_container_width=True):
        st.switch_page("pages/5_Review_Queue.py")
with qa3:
    if st.button("Browse Case Library", use_container_width=True):
        st.switch_page("pages/2_Case_Library.py")
with qa4:
    if st.button("Run Demo Case", use_container_width=True):
        st.session_state["run_demo"] = True
        st.switch_page("pages/1_Troubleshoot_Case.py")
st.markdown("</div>", unsafe_allow_html=True)
