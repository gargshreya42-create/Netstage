"""
Central API client for the NetSage AI Streamlit frontend.

Every call to the FastAPI backend goes through here, mirroring the same
REST API the previous React frontend used — the backend itself is
unchanged. Keeping this in one module means base URL / error handling /
timeout config lives in exactly one place.
"""
import os

import requests
import streamlit as st

API_BASE_URL = os.environ.get("NETSAGE_API_BASE_URL", "http://localhost:8000")
TIMEOUT = 30


class ApiError(Exception):
    def __init__(self, message, status=None, detail=None):
        super().__init__(message)
        self.status = status
        self.detail = detail


def _request(method, path, **kwargs):
    url = f"{API_BASE_URL}{path}"
    try:
        resp = requests.request(method, url, timeout=TIMEOUT, **kwargs)
    except requests.exceptions.ConnectionError as e:
        raise ApiError(
            f"Could not reach the NetSage AI backend at {API_BASE_URL}. "
            f"Is it running (uvicorn app.main:app --reload)?"
        ) from e
    except requests.exceptions.Timeout as e:
        raise ApiError(f"Request to {path} timed out after {TIMEOUT}s.") from e

    if not resp.ok:
        try:
            body = resp.json()
            detail = body.get("detail", resp.text)
        except ValueError:
            detail = resp.text
        raise ApiError(
            detail if isinstance(detail, str) else str(detail),
            status=resp.status_code,
            detail=detail,
        )

    if resp.status_code == 204 or not resp.content:
        return None
    return resp.json()


def _get(path, params=None):
    clean_params = {k: v for k, v in (params or {}).items() if v not in (None, "")}
    return _request("GET", path, params=clean_params)


def _post(path, json_body=None):
    return _request("POST", path, json=json_body if json_body is not None else {})


# --- System ---
def health():
    return _get("/api/health")


# --- Cases ---
def list_cases(search=None, concept_tag=None, severity=None):
    return _get("/api/cases", {"search": search, "concept_tag": concept_tag, "severity": severity})


def get_case(case_id):
    return _get(f"/api/cases/{case_id}")


def create_case(payload):
    return _post("/api/cases", payload)


# --- Rules ---
def check_rules(case_id):
    return _post(f"/api/rules/check/{case_id}")


# --- Diagnosis ---
def diagnose(case_id, force_ai=True):
    return _post(f"/api/diagnose/{case_id}", {"force_ai": force_ai})


def list_diagnoses(case_id=None, status=None):
    return _get("/api/diagnoses", {"case_id": case_id, "status": status})


def get_diagnosis(diagnosis_id):
    return _get(f"/api/diagnoses/{diagnosis_id}")


# --- Reviews ---
def approve_diagnosis(diagnosis_id, reviewer_comment=None):
    return _post(f"/api/reviews/{diagnosis_id}/approve", {"reviewer_comment": reviewer_comment})


def edit_diagnosis(diagnosis_id, edited_commands, reviewer_comment=None):
    return _post(
        f"/api/reviews/{diagnosis_id}/edit",
        {"edited_commands": edited_commands, "reviewer_comment": reviewer_comment},
    )


def reject_diagnosis(diagnosis_id, rejection_reason, reviewer_comment=None):
    return _post(
        f"/api/reviews/{diagnosis_id}/reject",
        {"rejection_reason": rejection_reason, "reviewer_comment": reviewer_comment},
    )


def verify_diagnosis(diagnosis_id):
    return _get(f"/api/reviews/{diagnosis_id}/verify")


def get_review_queue():
    return _get("/api/reviews/queue")


# --- Audit ---
def get_audit_log(case_id=None, event_type=None, limit=200):
    return _get("/api/audit", {"case_id": case_id, "event_type": event_type, "limit": limit})


# --- Analytics ---
def get_analytics():
    return _get("/api/analytics")


@st.cache_data(ttl=15, show_spinner=False)
def cached_health():
    """Health checks happen on every page load — cache briefly to avoid hammering the backend."""
    try:
        return health()
    except ApiError:
        return None
