"""
Reusable rendering helpers shared across pages.
"""
import html
import re

import streamlit as st

from lib.styling import COLORS, severity_badge_html, status_badge_html  # noqa: F401

_DOWN_PATTERN = re.compile(
    r"\b(administratively down|line protocol is down|down,|denied|failed|timed out|"
    r"not in table|disabled|notconnect)\b", re.IGNORECASE,
)
_UP_PATTERN = re.compile(r"\b(is up|line protocol is up|SUCCESS|active|permit)\b", re.IGNORECASE)
_WARN_PATTERN = re.compile(r"\b(interference|duplicate|mismatch|exhausted|overlap)\b", re.IGNORECASE)
_PROMPT_PATTERN = re.compile(r"^\S+[#>]\s*$")


def _highlight_line(line):
    stripped = line.strip()
    is_prompt = bool(_PROMPT_PATTERN.match(stripped)) and len(stripped) < 80
    is_down = bool(_DOWN_PATTERN.search(line))
    is_up = bool(_UP_PATTERN.search(line)) and not is_down
    is_warn = bool(_WARN_PATTERN.search(line))

    color = COLORS["text_primary"]
    if is_prompt:
        color = COLORS["accent_ai"]
    elif is_down:
        color = COLORS["sev_critical"]
    elif is_warn:
        color = COLORS["sev_medium"]
    elif is_up:
        color = COLORS["accent_ok"]

    escaped = html.escape(line) if line.strip() else "&nbsp;"
    return f'<div style="color:{color};">{escaped}</div>'


def render_terminal_output(text, title="show-command output"):
    """The signature evidence panel — syntax-highlighted raw show-command output."""
    lines = (text or "").split("\n")
    body = "".join(_highlight_line(l) for l in lines)
    st.markdown(
        f"""
        <div class="ns-terminal">
            <div class="ns-terminal-chrome">
                <span style="width:9px;height:9px;border-radius:50%;background:{COLORS['sev_critical']};display:inline-block;"></span>
                <span style="width:9px;height:9px;border-radius:50%;background:{COLORS['sev_medium']};display:inline-block;margin-left:4px;"></span>
                <span style="width:9px;height:9px;border-radius:50%;background:{COLORS['accent_ok']};display:inline-block;margin-left:4px;"></span>
                <span style="margin-left:8px;">{html.escape(title)}</span>
            </div>
            <div class="ns-terminal-body">{body}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_bar_row(label, value, max_value, color):
    pct = max((value / max_value) * 100, 3 if value > 0 else 0) if max_value else 0
    st.markdown(
        f"""
        <div style="display:grid;grid-template-columns:110px 1fr 40px;align-items:center;gap:10px;margin-bottom:10px;">
            <span style="font-size:12px;color:{COLORS['text_secondary']};font-family:'IBM Plex Mono',monospace;">{html.escape(str(label))}</span>
            <div style="background:#060a13;border-radius:4px;height:10px;overflow:hidden;">
                <div style="width:{pct}%;height:100%;background:{color};border-radius:4px;"></div>
            </div>
            <span style="font-size:12px;color:{COLORS['text_primary']};font-family:'IBM Plex Mono',monospace;text-align:right;">{value}</span>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_distribution_chart(data: dict, color_fn=None):
    if not data:
        st.caption("No data yet.")
        return
    max_value = max(data.values()) if data.values() else 1
    for label, value in data.items():
        color = color_fn(label) if color_fn else COLORS["accent_ai"]
        render_bar_row(label, value, max_value, color)


def severity_color(severity):
    return {
        "Low": COLORS["sev_low"], "Medium": COLORS["sev_medium"],
        "High": COLORS["sev_high"], "Critical": COLORS["sev_critical"],
    }.get(severity, COLORS["accent_ai"])


def render_badge(html_str):
    st.markdown(html_str, unsafe_allow_html=True)


def status_pill(label, color):
    st.markdown(
        f"""
        <div style="display:inline-flex;align-items:center;gap:8px;padding:6px 12px;border-radius:999px;
             border:1px solid {color}55;background:{color}14;font-family:'IBM Plex Mono',monospace;
             font-size:11px;letter-spacing:0.03em;color:{color};">
            <span style="width:6px;height:6px;border-radius:50%;background:{color};display:inline-block;"></span>
            {html.escape(label)}
        </div>
        """,
        unsafe_allow_html=True,
    )


def human_review_banner():
    st.markdown(
        f"""
        <div class="ns-human-review-banner">
            <strong>HUMAN REVIEW REQUIRED</strong>
            <span style="font-size:12px;color:{COLORS['text_secondary']};margin-left:10px;">
                No command is ever executed automatically. Approve, edit, or reject below.
            </span>
        </div>
        """,
        unsafe_allow_html=True,
    )


def page_header(eyebrow, title, subtitle):
    st.markdown(f'<div class="ns-eyebrow">{html.escape(eyebrow)}</div>', unsafe_allow_html=True)
    st.title(title)
    st.markdown(f'<p style="margin-bottom:24px;">{html.escape(subtitle)}</p>', unsafe_allow_html=True)
