"""
Design system for the NetSage AI Streamlit app, injected as CSS.

Streamlit doesn't expose a component-level styling API, so this targets
Streamlit's own DOM structure directly. It's more fragile across Streamlit
versions than a hand-built frontend would be, but keeps the same NOC/
terminal visual language (deep blue-black panels, monospace display type,
severity/status color coding) that the rest of this project uses.
"""
import streamlit as st

COLORS = {
    "bg_void": "#080c15",
    "bg_canvas": "#0a1120",
    "bg_panel": "#10192b",
    "bg_panel_alt": "#141f36",
    "border": "#1f2c47",
    "border_bright": "#2c3f66",
    "text_primary": "#e8edf7",
    "text_secondary": "#91a3c4",
    "text_dim": "#5b6c8f",
    "accent_ai": "#47d6ff",
    "accent_human": "#f2a93b",
    "accent_ok": "#33d690",
    "sev_low": "#47d6ff",
    "sev_medium": "#f2c94c",
    "sev_high": "#f2994a",
    "sev_critical": "#f2495c",
    "status_pending": "#f2a93b",
    "status_accepted": "#33d690",
    "status_edited": "#47d6ff",
    "status_rejected": "#f2495c",
}

SEVERITY_BG = {
    "Low": "#10283a",
    "Medium": "#3a2f10",
    "High": "#3a2410",
    "Critical": "#3a1018",
}

STATUS_LABELS = {
    "PENDING_REVIEW": "Pending Review",
    "ACCEPTED": "Accepted",
    "EDITED": "Edited",
    "REJECTED": "Rejected",
}


def inject_css():
    st.markdown(
        f"""
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600;700&family=IBM+Plex+Sans:wght@400;500;600&display=swap" rel="stylesheet">
        <style>
        html, body, [class*="css"] {{
            font-family: 'IBM Plex Sans', sans-serif;
        }}
        .stApp {{
            background-color: {COLORS['bg_void']};
            color: {COLORS['text_primary']};
        }}
        section[data-testid="stSidebar"] {{
            background-color: {COLORS['bg_canvas']};
            border-right: 1px solid {COLORS['border']};
        }}
        h1, h2, h3, h4 {{
            font-family: 'IBM Plex Mono', monospace !important;
            color: {COLORS['text_primary']} !important;
        }}
        p, span, label, div {{
            color: {COLORS['text_secondary']};
        }}
        code {{
            font-family: 'IBM Plex Mono', monospace !important;
            color: {COLORS['accent_ai']} !important;
            background: {COLORS['bg_panel_alt']} !important;
        }}
        .stButton > button {{
            font-family: 'IBM Plex Mono', monospace;
            font-size: 12px;
            font-weight: 600;
            letter-spacing: 0.04em;
            text-transform: uppercase;
            background: {COLORS['bg_panel_alt']};
            color: {COLORS['text_primary']};
            border: 1px solid {COLORS['border_bright']};
            border-radius: 8px;
            padding: 8px 18px;
        }}
        .stButton > button:hover {{
            border-color: {COLORS['text_dim']};
            background: #182642;
            color: {COLORS['text_primary']};
        }}
        .stButton > button[kind="primary"] {{
            background: {COLORS['accent_ai']};
            border-color: {COLORS['accent_ai']};
            color: #06121f;
        }}
        div[data-testid="stMetric"] {{
            background: {COLORS['bg_panel']};
            border: 1px solid {COLORS['border']};
            border-radius: 12px;
            padding: 14px 18px;
        }}
        div[data-testid="stMetricLabel"] {{
            font-family: 'IBM Plex Mono', monospace;
            font-size: 11px;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            color: {COLORS['text_dim']} !important;
        }}
        div[data-testid="stMetricValue"] {{
            font-family: 'IBM Plex Mono', monospace;
            color: {COLORS['text_primary']} !important;
        }}
        .streamlit-expanderHeader {{
            font-family: 'IBM Plex Mono', monospace;
            background: {COLORS['bg_panel_alt']};
        }}
        div[data-testid="stDataFrame"] {{
            border: 1px solid {COLORS['border']};
            border-radius: 8px;
        }}
        hr {{
            border-color: {COLORS['border']};
        }}
        .ns-panel {{
            background: {COLORS['bg_panel']};
            border: 1px solid {COLORS['border']};
            border-radius: 12px;
            padding: 18px 20px;
            margin-bottom: 16px;
        }}
        .ns-eyebrow {{
            font-family: 'IBM Plex Mono', monospace;
            font-size: 11px;
            letter-spacing: 0.12em;
            text-transform: uppercase;
            color: {COLORS['text_dim']};
            margin-bottom: 4px;
        }}
        .ns-badge {{
            display: inline-flex;
            align-items: center;
            gap: 6px;
            font-family: 'IBM Plex Mono', monospace;
            font-size: 11px;
            font-weight: 600;
            letter-spacing: 0.04em;
            text-transform: uppercase;
            padding: 4px 10px;
            border-radius: 999px;
            white-space: nowrap;
        }}
        .ns-dot {{
            width: 6px;
            height: 6px;
            border-radius: 50%;
            display: inline-block;
        }}
        .ns-terminal {{
            background: #060a13;
            border: 1px solid {COLORS['border']};
            border-radius: 8px;
            overflow: hidden;
            margin-bottom: 12px;
        }}
        .ns-terminal-chrome {{
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 12px;
            background: {COLORS['bg_panel_alt']};
            border-bottom: 1px solid {COLORS['border']};
            font-family: 'IBM Plex Mono', monospace;
            font-size: 11px;
            color: {COLORS['text_dim']};
        }}
        .ns-terminal-body {{
            padding: 14px 16px;
            font-family: 'IBM Plex Mono', monospace;
            font-size: 12.5px;
            line-height: 1.7;
            max-height: 340px;
            overflow-y: auto;
            white-space: pre-wrap;
            word-break: break-word;
        }}
        .ns-human-review-banner {{
            background: #5a4319;
            border: 1px solid {COLORS['accent_human']};
            border-radius: 8px;
            padding: 12px 16px;
            margin-bottom: 16px;
        }}
        .ns-human-review-banner strong {{
            font-family: 'IBM Plex Mono', monospace;
            color: {COLORS['accent_human']};
            letter-spacing: 0.05em;
        }}
        </style>
        """,
        unsafe_allow_html=True,
    )


def severity_badge_html(severity):
    color = {
        "Low": COLORS["sev_low"], "Medium": COLORS["sev_medium"],
        "High": COLORS["sev_high"], "Critical": COLORS["sev_critical"],
    }.get(severity, COLORS["sev_medium"])
    bg = SEVERITY_BG.get(severity, SEVERITY_BG["Medium"])
    return (
        f'<span class="ns-badge" style="color:{color};background:{bg};'
        f'border:1px solid {color}40;"><span class="ns-dot" style="background:{color};"></span>{severity}</span>'
    )


def status_badge_html(status):
    color = {
        "PENDING_REVIEW": COLORS["status_pending"], "ACCEPTED": COLORS["status_accepted"],
        "EDITED": COLORS["status_edited"], "REJECTED": COLORS["status_rejected"],
    }.get(status, COLORS["text_dim"])
    label = STATUS_LABELS.get(status, status or "Unknown")
    return (
        f'<span class="ns-badge" style="color:{color};background:{color}1a;'
        f'border:1px solid {color}40;"><span class="ns-dot" style="background:{color};"></span>{label}</span>'
    )
